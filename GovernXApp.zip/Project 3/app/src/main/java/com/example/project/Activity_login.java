package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Activity_login extends AppCompatActivity {

    // Login form fields
    private EditText edtLoginEmail;
    private EditText edtLoginPassword;
    private Button btnLogin;
    private TextView txtGoSignUp;
    private ImageButton btnBack;

    // Firebase Auth
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Edge-to-edge padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Init FirebaseAuth
        mAuth = FirebaseAuth.getInstance();

        // Init views
        edtLoginEmail = findViewById(R.id.edtLoginEmail);
        edtLoginPassword = findViewById(R.id.edtLoginPassword);
        btnLogin = findViewById(R.id.btnLogin);
        txtGoSignUp = findViewById(R.id.txtGoSignUp);
        btnBack = findViewById(R.id.btnBack);

        // Back button → close screen
        btnBack.setOnClickListener(v -> finish());

        // Go to sign up screen
        txtGoSignUp.setOnClickListener(v -> {
            startActivity(new Intent(this, Activity_sign.class));
        });

        // Login button
        btnLogin.setOnClickListener(v -> {
            String email = edtLoginEmail.getText().toString().trim();
            String password = edtLoginPassword.getText().toString().trim();

            // Email required
            if (TextUtils.isEmpty(email)) {
                edtLoginEmail.setError("Email is required");
                edtLoginEmail.requestFocus();
                return;
            }

            // Email format check
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtLoginEmail.setError("Please enter a valid email address");
                edtLoginEmail.requestFocus();
                return;
            }

            // Password required
            if (TextUtils.isEmpty(password)) {
                edtLoginPassword.setError("Password is required");
                edtLoginPassword.requestFocus();
                return;
            }

            // Sign in with Firebase
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(this, MainActivity.class));
                                finish();
                            }
                        } else {
                            String message = task.getException() != null
                                    ? task.getException().getMessage()
                                    : "Login failed";
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}
