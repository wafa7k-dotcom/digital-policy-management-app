package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    // Dashboard counters
    private TextView tvActiveCount, tvReviewCount, tvArchivedCount, tvDueSoon;

    // Firestore + date format
    private FirebaseFirestore db;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("M/d/yyyy", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Setup toolbar
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Init views
        tvActiveCount = findViewById(R.id.tvActiveCount);
        tvReviewCount = findViewById(R.id.tvReviewCount);
        tvArchivedCount = findViewById(R.id.tvArchivedCount);
        tvDueSoon = findViewById(R.id.tvDueSoon);

        // Init Firestore
        db = FirebaseFirestore.getInstance();

        // Listen to policies collection in real time
        db.collection("policies").addSnapshotListener((snapshots, error) -> {
            if (error != null) {
                Toast.makeText(DashboardActivity.this,
                        "Failed to load stats", Toast.LENGTH_SHORT).show();
                return;
            }
            if (snapshots == null) return;

            int active = 0;
            int needsReview = 0;
            int archived = 0;

            // Track earliest review date (for "due soon")
            Date earliestDate = null;
            String dueSoonTitle = null;
            String dueSoonDateText = null;

            for (QueryDocumentSnapshot doc : snapshots) {
                Policy policy = doc.toObject(Policy.class);

                String status = policy.getStatus();
                String reviewDateStr = policy.getReviewDate();

                // Count by status
                if ("Active".equalsIgnoreCase(status)) {
                    active++;
                } else if ("Needs Review".equalsIgnoreCase(status)) {
                    needsReview++;
                } else if ("Archived".equalsIgnoreCase(status)) {
                    archived++;
                }

                // Find earliest review date
                if (reviewDateStr != null && !reviewDateStr.isEmpty()) {
                    try {
                        Date d = dateFormat.parse(reviewDateStr);
                        if (d != null && (earliestDate == null || d.before(earliestDate))) {
                            earliestDate = d;
                            dueSoonTitle = policy.getTitle();
                            dueSoonDateText = reviewDateStr;
                        }
                    } catch (ParseException e) {
                        // Ignore invalid date format
                    }
                }
            }

            // Update UI counters
            tvActiveCount.setText(String.valueOf(active));
            tvReviewCount.setText(String.valueOf(needsReview));
            tvArchivedCount.setText(String.valueOf(archived));

            // Update "due soon" card
            if (dueSoonTitle != null) {
                tvDueSoon.setText(dueSoonTitle + "\n" + dueSoonDateText);
            } else {
                tvDueSoon.setText("No upcoming reviews");
            }
        });
    }

    // Inflate top menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_top, menu);
        return true;
    }

    // Handle top menu clicks
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_policies) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        } else if (id == R.id.menu_dashboard) {
            // Already on dashboard
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
