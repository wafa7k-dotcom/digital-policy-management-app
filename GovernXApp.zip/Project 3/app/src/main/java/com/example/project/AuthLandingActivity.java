package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AuthLandingActivity extends AppCompatActivity {

    // Buttons for navigation
    private Button btnGoSignUp, btnGoLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_auth_landing);

        // Handle edge-to-edge layout padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_auth), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Init buttons
        btnGoSignUp = findViewById(R.id.btnGoSignUp);
        btnGoLogin = findViewById(R.id.btnGoLogin);

        // Navigate to Sign Up screen
        btnGoSignUp.setOnClickListener(v -> {
            startActivity(new Intent(this, Activity_sign.class));
        });

        // Navigate to Login screen
        btnGoLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, Activity_login.class));
        });
    }
}
