package com.example.project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PolicyAdapter extends RecyclerView.Adapter<PolicyAdapter.PolicyViewHolder> {

    // Listener for item clicks
    public interface OnItemClickListener {
        void onClick(Policy policy);
    }

    private List<Policy> policyList;
    private OnItemClickListener listener;

    // Adapter constructor (takes list + listener)
    public PolicyAdapter(List<Policy> policyList, OnItemClickListener listener) {
        this.policyList = policyList;
        this.listener = listener;
    }

    @NonNull
    @Override
    // Create ViewHolder
    public PolicyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_policy, parent, false);
        return new PolicyViewHolder(view);
    }

    @Override
    // Bind data to each item
    public void onBindViewHolder(@NonNull PolicyViewHolder holder, int position) {
        Policy policy = policyList.get(position);
        holder.tvTitle.setText(policy.getTitle());
        holder.tvDate.setText(policy.getReviewDate());
        holder.tvStatus.setText(policy.getStatus());

        // Handle item click
        holder.itemView.setOnClickListener(v -> listener.onClick(policy));
    }

    @Override
    // Number of items
    public int getItemCount() {
        return policyList.size();
    }

    static class PolicyViewHolder extends RecyclerView.ViewHolder {

        // UI elements
        TextView tvTitle, tvDate, tvStatus;

        public PolicyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}
