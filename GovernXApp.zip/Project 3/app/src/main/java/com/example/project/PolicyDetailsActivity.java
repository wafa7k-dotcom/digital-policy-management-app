package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class PolicyDetailsActivity extends AppCompatActivity {

    private TextView tvTitle, tvDescription, tvOwner, tvStatus, tvReviewDate;
    private MaterialButton btnEdit, btnDelete;

    private FirebaseFirestore db;

    // Values passed from MainActivity
    private String title, description, owner, status, reviewDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_details);

        // Toolbar back
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        toolbar.setNavigationOnClickListener(v -> finish());

        db = FirebaseFirestore.getInstance();

        // Get data from intent
        title = getIntent().getStringExtra("title");
        description = getIntent().getStringExtra("description");
        owner = getIntent().getStringExtra("owner");
        status = getIntent().getStringExtra("status");
        reviewDate = getIntent().getStringExtra("reviewDate");

        // Bind views
        tvTitle = findViewById(R.id.tvTitle);
        tvDescription = findViewById(R.id.tvDescription);
        tvOwner = findViewById(R.id.tvOwner);
        tvStatus = findViewById(R.id.tvStatus);
        tvReviewDate = findViewById(R.id.tvReviewDate);

        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);

        // Show data
        tvTitle.setText(title);
        tvDescription.setText(description);
        tvOwner.setText(owner);
        tvStatus.setText(status);
        tvReviewDate.setText(reviewDate);

        // EDIT -> open AddPolicyActivity in edit mode
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(PolicyDetailsActivity.this, AddPolicyActivity.class);
            intent.putExtra("editMode", true);
            intent.putExtra("title", title);
            intent.putExtra("description", description);
            intent.putExtra("owner", owner);
            intent.putExtra("status", status);
            intent.putExtra("reviewDate", reviewDate);
            startActivity(intent);
            finish(); // close details, user will go back to main after update
        });

        // DELETE -> confirm then delete from Firestore
        btnDelete.setOnClickListener(v -> showDeleteDialog());
    }

    private void showDeleteDialog() {
        new AlertDialog.Builder(PolicyDetailsActivity.this)
                .setTitle("Delete Policy")
                .setMessage("Are you sure you want to delete this policy?")
                .setPositiveButton("DELETE", (dialog, which) -> deletePolicy())
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void deletePolicy() {
        db.collection("policies")
                .whereEqualTo("title", title)  // simple match by title
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    if (!querySnapshot.isEmpty()) {
                        for (QueryDocumentSnapshot doc : querySnapshot) {
                            doc.getReference().delete();
                        }
                        Toast.makeText(PolicyDetailsActivity.this,
                                "Policy deleted", Toast.LENGTH_SHORT).show();
                        finish(); // back to list – listener in MainActivity updates UI
                    } else {
                        Toast.makeText(PolicyDetailsActivity.this,
                                "Policy not found", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(PolicyDetailsActivity.this,
                                "Delete failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}



