package com.example.project;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.Calendar;

public class AddPolicyActivity extends AppCompatActivity {

    // Form inputs
    private TextInputEditText etTitle, etDescription, etReviewDate;
    private AutoCompleteTextView etOwner, etStatus;
    private MaterialButton btnSave, btnCancel;

    // Firestore + edit state
    private FirebaseFirestore db;
    private boolean isEditMode = false;
    private String originalTitle; // find doc when editing

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_policy);

        // Views
        etTitle = findViewById(R.id.etTitle);
        etDescription = findViewById(R.id.etDescription);
        etOwner = findViewById(R.id.etOwner);
        etStatus = findViewById(R.id.etStatus);
        etReviewDate = findViewById(R.id.etReviewDate);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        // Toolbar back
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Firestore
        db = FirebaseFirestore.getInstance();

        // Dropdowns
        String[] owners = {"HR", "IT", "Finance", "Operations"};
        String[] statuses = {"Active", "Needs Review", "Archived"};

        etOwner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, owners));
        etStatus.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, statuses));

        // Date picker
        etReviewDate.setOnClickListener(v -> showDatePicker());

        // Cancel
        btnCancel.setOnClickListener(v -> finish());

        // Edit mode: fill existing data
        isEditMode = getIntent().getBooleanExtra("editMode", false);
        if (isEditMode) {
            originalTitle = getIntent().getStringExtra("title");

            etTitle.setText(originalTitle);
            etDescription.setText(getIntent().getStringExtra("description"));
            etOwner.setText(getIntent().getStringExtra("owner"));
            etStatus.setText(getIntent().getStringExtra("status"));
            etReviewDate.setText(getIntent().getStringExtra("reviewDate"));

            btnSave.setText("UPDATE");
        }

        // Save
        btnSave.setOnClickListener(v -> savePolicy());
    }

    // Save or update policy in Firestore
    private void savePolicy() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String owner = etOwner.getText().toString().trim();
        String status = etStatus.getText().toString().trim();
        String reviewDate = etReviewDate.getText().toString().trim();

        // Required fields check
        if (title.isEmpty() || description.isEmpty() ||
                owner.isEmpty() || status.isEmpty() || reviewDate.isEmpty()) {
            Toast.makeText(AddPolicyActivity.this,
                    "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Policy policy = new Policy(title, description, owner, status, reviewDate);
        CollectionReference policiesRef = db.collection("policies");

        if (isEditMode) {
            // Update existing doc (by title)
            policiesRef.whereEqualTo("title", originalTitle)
                    .get()
                    .addOnSuccessListener(querySnapshots -> {
                        if (!querySnapshots.isEmpty()) {
                            for (QueryDocumentSnapshot doc : querySnapshots) {
                                doc.getReference().set(policy);
                            }
                            Toast.makeText(AddPolicyActivity.this,
                                    "Policy updated", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(AddPolicyActivity.this,
                                    "Policy not found", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(AddPolicyActivity.this,
                                    "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );

        } else {
            // Add new policy
            policiesRef.add(policy)
                    .addOnSuccessListener(ref -> {
                        Toast.makeText(AddPolicyActivity.this,
                                "Policy added", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(AddPolicyActivity.this,
                                    "Failed to add: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );
        }
    }

    // Show date picker
    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        new DatePickerDialog(
                AddPolicyActivity.this,
                (view, year, month, dayOfMonth) -> {
                    String date = (month + 1) + "/" + dayOfMonth + "/" + year;
                    etReviewDate.setText(date);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }
}
