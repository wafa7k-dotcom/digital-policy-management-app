package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvPolicies;
    private FloatingActionButton fabAdd;
    private PolicyAdapter adapter;
    private ArrayList<Policy> policyList;

    // Firestore reference
    private FirebaseFirestore db;
    private CollectionReference policiesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Init Firebase
        FirebaseApp.initializeApp(this);
        db = FirebaseFirestore.getInstance();
        policiesRef = db.collection("policies");

        // Setup toolbar
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Back arrow click
        toolbar.setNavigationOnClickListener(v -> {
            finish();
            // Or navigate to a specific activity:
            // startActivity(new Intent(this, AuthLandingActivity.class));
        });

        // RecyclerView + FAB
        rvPolicies = findViewById(R.id.rvPolicies);
        fabAdd = findViewById(R.id.fabAdd);
        rvPolicies.setLayoutManager(new LinearLayoutManager(this));

        // Init list + adapter
        policyList = new ArrayList<>();
        adapter = new PolicyAdapter(policyList, this::openPolicyDetails);
        rvPolicies.setAdapter(adapter);

        // Listen for changes in Firestore
        policiesRef.addSnapshotListener((snapshots, error) -> {
            if (error != null) {
                Toast.makeText(MainActivity.this, "Failed to load policies", Toast.LENGTH_SHORT).show();
                return;
            }
            if (snapshots == null) return;

            policyList.clear();
            for (QueryDocumentSnapshot doc : snapshots) {
                Policy policy = doc.toObject(Policy.class);
                policyList.add(policy);
            }
            adapter.notifyDataSetChanged(); // Refresh list
        });

        // Add button click
        fabAdd.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddPolicyActivity.class)));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate top menu
        getMenuInflater().inflate(R.menu.menu_top, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle top menu clicks
        int id = item.getItemId();
        if (id == R.id.menu_policies) {
            // Already in policies screen
            return true;
        } else if (id == R.id.menu_dashboard) {
            startActivity(new Intent(this, DashboardActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Open policy details screen
    private void openPolicyDetails(Policy policy) {
        Intent intent = new Intent(this, PolicyDetailsActivity.class);
        intent.putExtra("title", policy.getTitle());
        intent.putExtra("description", policy.getDescription());
        intent.putExtra("owner", policy.getOwner());
        intent.putExtra("status", policy.getStatus());
        intent.putExtra("reviewDate", policy.getReviewDate());
        startActivity(intent);
    }
}
