package com.example.project;

public class Policy {

    // Policy model fields
    private String title;
    private String description;
    private String owner;
    private String status;
    private String reviewDate;

    // Empty constructor for Firestore
    public Policy() {}

    // Constructor to create a Policy object
    public Policy(String title, String description, String owner, String status, String reviewDate) {
        this.title = title;
        this.description = description;
        this.owner = owner;
        this.status = status;
        this.reviewDate = reviewDate;
    }

    // Getters for all fields
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getOwner() { return owner; }
    public String getStatus() { return status; }
    public String getReviewDate() { return reviewDate; }
}
