package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;

public class Activity_sign extends AppCompatActivity {

    // Register form fields
    private EditText edtSignEmail;
    private EditText edtSignPassword;
    private EditText edtSignConfirmPassword;
    private Button btnSign;
    private TextView txtGoLogin;
    private ImageButton btnBack;

    // Firebase Auth
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sign);

        // Edge-to-edge padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_sign), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Init FirebaseAuth
        mAuth = FirebaseAuth.getInstance();

        // Init views
        edtSignEmail = findViewById(R.id.edtRegisterEmail);
        edtSignPassword = findViewById(R.id.edtRegisterPassword);
        edtSignConfirmPassword = findViewById(R.id.edtRegisterConfirmPassword);
        btnSign = findViewById(R.id.btnRegister);
        txtGoLogin = findViewById(R.id.txtGoLogin);
        btnBack = findViewById(R.id.btnBack);

        // Back button → close screen
        btnBack.setOnClickListener(v -> finish());

        // Go to login screen
        txtGoLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, Activity_login.class));
            finish();
        });

        // Register button
        btnSign.setOnClickListener(v -> {
            String email = edtSignEmail.getText().toString().trim();
            String password = edtSignPassword.getText().toString().trim();
            String confirm = edtSignConfirmPassword.getText().toString().trim();

            // Email required
            if (TextUtils.isEmpty(email)) {
                edtSignEmail.setError("Email is required");
                edtSignEmail.requestFocus();
                return;
            }

            // Email format check
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtSignEmail.setError("Please enter a valid email address");
                edtSignEmail.requestFocus();
                return;
            }

            // Password required
            if (TextUtils.isEmpty(password)) {
                edtSignPassword.setError("Password is required");
                edtSignPassword.requestFocus();
                return;
            }

            // Password length
            if (password.length() < 6) {
                edtSignPassword.setError("Password must be at least 6 characters");
                edtSignPassword.requestFocus();
                return;
            }

            // Confirm password match
            if (!password.equals(confirm)) {
                edtSignConfirmPassword.setError("Passwords do not match");
                edtSignConfirmPassword.requestFocus();
                return;
            }

            // Create user in Firebase
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(this, Activity_login.class));
                            finish();
                        } else {
                            String message = task.getException() != null
                                    ? task.getException().getMessage()
                                    : "Failed to create account";
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}
